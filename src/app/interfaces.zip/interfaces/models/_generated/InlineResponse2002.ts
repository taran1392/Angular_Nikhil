

import * as models from './models';


export interface InlineResponse2002 {
    "tenants": Array<models.InlineResponse2002Tenants>;
}

