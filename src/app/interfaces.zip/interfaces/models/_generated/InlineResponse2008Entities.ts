

import * as models from './models';


export interface InlineResponse2008Entities {
    
    "entityId"?: string;
    
    "entailingTokenNumbers"?: Array<number>;
}

