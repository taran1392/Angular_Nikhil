

import * as models from './models';


export interface InlineResponse2005NoIncludeIntents {
    
    "agentId": string;
    
    "intentId": string;
}

