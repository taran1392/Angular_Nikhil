

import * as models from './models';


export interface Body4 {
    
    "id": string;
    
    "values": Array<string>;
}

