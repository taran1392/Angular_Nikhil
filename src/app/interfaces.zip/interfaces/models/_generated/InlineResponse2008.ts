

import * as models from './models';


export interface InlineResponse2008 {
    
    "total": number;
    
    "amount": number;
    
    "start": number;
    "utterances": Array<models.InlineResponse2008Utterances>;
}

