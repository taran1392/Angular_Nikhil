

import * as models from './models';


export interface NoIncludeIntent {
    
    "agentId": string;
    
    "intentId": string;
}

