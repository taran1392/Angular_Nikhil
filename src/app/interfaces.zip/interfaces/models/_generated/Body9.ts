

import * as models from './models';


export interface Body9 {
    
    "id": string;
    
    "tokenizedString": Array<string>;
    
    "entities": Array<models.InlineResponse2008Entities>;
}

