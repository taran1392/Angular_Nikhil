

import * as models from './models';


export interface InlineResponse2004Attributes {
    
    "name": string;
    
    "value": string;
}

