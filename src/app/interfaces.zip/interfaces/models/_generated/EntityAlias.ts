

import * as models from './models';


export interface EntityAlias {
    
    "entityId"?: string;
    
    "entailingTokenNumbers"?: Array<number>;
}

