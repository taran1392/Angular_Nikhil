

import * as models from './models';


export interface Body5 {
    
    "id": string;
    
    "values": Array<string>;
}

