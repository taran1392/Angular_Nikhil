

import * as models from './models';


export interface Tenant {
    "id": string;
    "name": string;
}

