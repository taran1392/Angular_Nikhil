

import * as models from './models';


export interface InlineResponse2001 {
    "version"?: string;
    "buildid"?: string;
    "apiEndpoints"?: Array<models.InlineResponse2001ApiEndpoints>;
}

