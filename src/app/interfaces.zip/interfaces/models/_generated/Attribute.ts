

import * as models from './models';


export interface Attribute {
    
    "name": string;
    
    "value": string;
}

