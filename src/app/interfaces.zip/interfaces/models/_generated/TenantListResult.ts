

import * as models from './models';


export interface TenantListResult {
    "tenants": Array<models.InlineResponse2002Tenants>;
}

