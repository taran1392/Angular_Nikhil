

import * as models from './models';


export interface InlineResponse2002Tenants {
    "id": string;
    "name": string;
}

