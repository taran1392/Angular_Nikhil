

import * as models from './models';


export interface Feature {
    
    "id": string;
    
    "values": Array<string>;
}

