import { TestBed, inject } from '@angular/core/testing';

import  {InlineResponse2004Attributes} from './InlineResponse2004Attributes';
import * as models from './models';


/*
"name": string;
    
    "value": string;
*/

describe('Interface : InlineResponse2004Attributes  ', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
    });
  });


  it("should create object ",()=>{
    

      let vObj:InlineResponse2004Attributes={
            name:"",
            value:""
    };
    expect(vObj).toBeTruthy();
  });

  }
);
