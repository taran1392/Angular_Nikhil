

import * as models from './models';

export interface InlineResponse2001ApiEndpoints {
    "version"?: string;
    "endpoint"?: string;
}

