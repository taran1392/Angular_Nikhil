

import * as models from './models';


export interface InlineResponse2006 {
    
    "id": string;
    
    "values": Array<string>;
}

