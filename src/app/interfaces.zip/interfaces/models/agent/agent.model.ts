import {Agent} from "../_generated/Agent";
export class AgentModel {
  
  constructor(values: Agent) {
    console.log(Object.keys(values))
    // Object.assign(this, values);
  }
}
